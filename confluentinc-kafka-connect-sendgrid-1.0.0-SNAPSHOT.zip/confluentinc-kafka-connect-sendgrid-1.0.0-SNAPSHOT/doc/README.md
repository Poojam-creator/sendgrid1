# kafka-sendgrid-connect
Custom connector for Kafka to SendGrid email service
